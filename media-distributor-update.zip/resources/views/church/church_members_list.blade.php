@extends('layouts.church.app')

@section('content')
    @livewire('church-members-list-page')
@endsection

