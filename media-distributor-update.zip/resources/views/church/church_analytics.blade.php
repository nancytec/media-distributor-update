@extends('layouts.church.app')

@section('content')
    @livewire('church-analytics-page')
@endsection

