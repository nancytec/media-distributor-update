@extends('layouts.church.app')

@section('content')
    @livewire('church-dashboard-page')
@endsection

