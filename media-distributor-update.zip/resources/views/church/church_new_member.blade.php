@extends('layouts.church.app')

@section('content')
    @livewire('church-new-member-page')
@endsection

