@extends('layouts.church.app')

@section('content')
    @livewire('church-shared-links-page')
@endsection

