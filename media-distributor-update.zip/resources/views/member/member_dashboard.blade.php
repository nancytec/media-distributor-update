@extends('layouts.member.app')

@section('content')
    @livewire('member-dashboard-page')
@endsection

