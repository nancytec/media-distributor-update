<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminRouteController extends Controller
{
    public function adminDashboardPage()
    {
        return view('admin.admin_dashboard');
    }
    public function adminAllMediaPage()
    {
        return view('admin.admin_all_media');
    }

    public function adminViewMediaPage($media_id)
    {
        return view('admin.admin_view_media', ['media_id' => $media_id]);
    }

    public function adminMediaTranslationsPage($media_id)
    {
        return view('admin.admin_media_translation', ['media_id' => $media_id]);
    }
}
