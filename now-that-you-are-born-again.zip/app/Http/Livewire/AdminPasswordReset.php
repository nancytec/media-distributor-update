<?php

namespace App\Http\Livewire;

use Livewire\Component;

class AdminPasswordReset extends Component
{
    public function render()
    {
        return view('livewire.admin.pages.admin-password-reset');
    }
}
