@extends('layouts.church.app')

@section('content')
    @livewire('church-all-media-page')
@endsection

