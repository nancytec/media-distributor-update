@extends('layouts.admin.app')

@section('content')
    @livewire('admin-dashboard-page')
@endsection

