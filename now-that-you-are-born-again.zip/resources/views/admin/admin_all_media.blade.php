@extends('layouts.admin.app')

@section('content')
    @livewire('admin-all-media-page')
@endsection

