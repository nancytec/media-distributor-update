@extends('layouts.member.app')

@section('content')
    @livewire('member-media-links-page')
@endsection

